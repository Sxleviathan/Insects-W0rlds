import { notFound } from "next/navigation"
import { ArrowLeft, Check } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { AddToCartButton } from "@/components/add-to-cart-button"
import { getProductById, reptiles } from "@/lib/products"

export function generateStaticParams() {
  return reptiles.map((product) => ({
    id: product.id,
  }))
}

export default function ReptileProductPage({ params }: { params: { id: string } }) {
  const product = getProductById(params.id)

  if (!product || product.category !== "reptile") {
    notFound()
  }

  return (
    <main className="min-h-screen py-12">
      <div className="container">
        <Link href="/reptiles" className="inline-flex items-center gap-2 text-muted-foreground hover:text-primary mb-8">
          <ArrowLeft className="h-4 w-4" />
          Retour aux reptiles
        </Link>

        <div className="grid md:grid-cols-2 gap-12">
          {/* Product Image */}
          <div className="aspect-square overflow-hidden rounded-lg bg-muted">
            <img src={product.image || "/placeholder.svg"} alt={product.name} className="w-full h-full object-cover" />
          </div>

          {/* Product Info */}
          <div className="space-y-6">
            <div>
              <Badge variant="secondary" className="mb-4">
                Reptile
              </Badge>
              <h1 className="font-serif text-4xl md:text-5xl text-foreground mb-4">{product.name}</h1>
              <p className="text-3xl font-medium text-primary mb-6">{product.price.toFixed(2)} €</p>
              <p className="text-muted-foreground leading-relaxed">{product.description}</p>
            </div>

            {/* Details */}
            <Card>
              <CardContent className="p-6">
                <h3 className="font-medium text-lg mb-4 text-foreground">Caractéristiques</h3>
                <ul className="space-y-3">
                  {product.details.map((detail, index) => (
                    <li key={index} className="flex items-start gap-3">
                      <Check className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                      <span className="text-muted-foreground">{detail}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>

            {/* Add to Cart */}
            <div className="space-y-4">
              {product.inStock ? (
                <AddToCartButton product={product} />
              ) : (
                <Button size="lg" disabled className="w-full rounded-full">
                  Rupture de stock
                </Button>
              )}
              <p className="text-sm text-muted-foreground text-center">
                Livraison gratuite pour les commandes de plus de 100€
              </p>
            </div>

            {/* Care Info */}
            <Card className="bg-muted/50">
              <CardContent className="p-6">
                <h3 className="font-medium text-lg mb-2 text-foreground">Conseils d'entretien</h3>
                <p className="text-sm text-muted-foreground">
                  Chaque reptile est livré avec un guide d'entretien complet. Notre équipe est disponible pour répondre
                  à toutes vos questions sur les soins et l'habitat.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </main>
  )
}
