"use client"

import Link from "next/link"
import { Minus, Plus, Trash2, ShoppingBag, ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { useCart } from "@/lib/cart-context"

export default function CartPage() {
  const { items, updateQuantity, removeItem, total } = useCart()

  if (items.length === 0) {
    return (
      <main className="min-h-screen py-16">
        <div className="container">
          <div className="max-w-2xl mx-auto text-center space-y-6">
            <div className="w-24 h-24 rounded-full bg-muted flex items-center justify-center mx-auto">
              <ShoppingBag className="h-12 w-12 text-muted-foreground" />
            </div>
            <h1 className="font-serif text-4xl text-foreground">Votre panier est vide</h1>
            <p className="text-muted-foreground">
              Découvrez notre collection de reptiles et plantes exotiques pour commencer vos achats
            </p>
            <div className="flex gap-4 justify-center flex-wrap">
              <Button size="lg" asChild className="rounded-full">
                <Link href="/reptiles">Explorer les Reptiles</Link>
              </Button>
              <Button size="lg" variant="outline" asChild className="rounded-full bg-transparent">
                <Link href="/plantes">Découvrir les Plantes</Link>
              </Button>
            </div>
          </div>
        </div>
      </main>
    )
  }

  return (
    <main className="min-h-screen py-12">
      <div className="container">
        <h1 className="font-serif text-4xl md:text-5xl text-foreground mb-8">Votre Panier</h1>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Cart Items */}
          <div className="lg:col-span-2 space-y-4">
            {items.map((item) => (
              <Card key={item.id}>
                <CardContent className="p-6">
                  <div className="flex gap-6">
                    {/* Product Image */}
                    <div className="w-24 h-24 rounded-lg overflow-hidden bg-muted flex-shrink-0">
                      <img
                        src={item.image || "/placeholder.svg"}
                        alt={item.name}
                        className="w-full h-full object-cover"
                      />
                    </div>

                    {/* Product Info */}
                    <div className="flex-1 min-w-0">
                      <div className="flex justify-between items-start gap-4 mb-3">
                        <div>
                          <h3 className="font-serif text-xl text-foreground mb-1">{item.name}</h3>
                          <p className="text-sm text-muted-foreground capitalize">{item.category}</p>
                        </div>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => removeItem(item.id)}
                          className="text-muted-foreground hover:text-destructive flex-shrink-0"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>

                      <div className="flex justify-between items-center">
                        {/* Quantity Controls */}
                        <div className="flex items-center gap-2">
                          <Button
                            variant="outline"
                            size="icon"
                            className="h-8 w-8 rounded-full bg-transparent"
                            onClick={() => updateQuantity(item.id, item.quantity - 1)}
                          >
                            <Minus className="h-3 w-3" />
                          </Button>
                          <span className="w-12 text-center font-medium text-foreground">{item.quantity}</span>
                          <Button
                            variant="outline"
                            size="icon"
                            className="h-8 w-8 rounded-full bg-transparent"
                            onClick={() => updateQuantity(item.id, item.quantity + 1)}
                          >
                            <Plus className="h-3 w-3" />
                          </Button>
                        </div>

                        {/* Price */}
                        <p className="text-lg font-medium text-primary">{(item.price * item.quantity).toFixed(2)} €</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <Card className="sticky top-24">
              <CardContent className="p-6 space-y-6">
                <h2 className="font-serif text-2xl text-foreground">Résumé</h2>

                <div className="space-y-3">
                  <div className="flex justify-between text-muted-foreground">
                    <span>Sous-total</span>
                    <span>{total.toFixed(2)} €</span>
                  </div>
                  <div className="flex justify-between text-muted-foreground">
                    <span>Livraison</span>
                    <span>{total >= 100 ? "Gratuite" : "9.99 €"}</span>
                  </div>
                  <div className="border-t border-border pt-3">
                    <div className="flex justify-between text-lg font-medium text-foreground">
                      <span>Total</span>
                      <span className="text-primary">{(total >= 100 ? total : total + 9.99).toFixed(2)} €</span>
                    </div>
                  </div>
                </div>

                {total < 100 && (
                  <div className="bg-muted/50 rounded-lg p-4">
                    <p className="text-sm text-muted-foreground">
                      Ajoutez <span className="font-medium text-foreground">{(100 - total).toFixed(2)} €</span> pour
                      bénéficier de la livraison gratuite
                    </p>
                  </div>
                )}

                <Button size="lg" asChild className="w-full rounded-full">
                  <Link href="/checkout">
                    Passer la commande
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>

                <Button variant="outline" size="lg" asChild className="w-full rounded-full bg-transparent">
                  <Link href="/">Continuer mes achats</Link>
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </main>
  )
}
