import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { ArrowRight } from "lucide-react"

export default function HomePage() {
  const featuredProducts = [
    {
      id: "1",
      name: "Gecko Léopard",
      category: "Reptiles",
      price: 89.99,
      image: "/leopard-gecko-reptile.jpg",
      href: "/reptiles/gecko-leopard",
    },
    {
      id: "2",
      name: "Monstera Deliciosa",
      category: "Plantes",
      price: 34.99,
      image: "/monstera-deliciosa-tropical-plant.jpg",
      href: "/plantes/monstera",
    },
    {
      id: "3",
      name: "Python Royal",
      category: "Reptiles",
      price: 149.99,
      image: "/ball-python-snake.jpg",
      href: "/reptiles/python-royal",
    },
  ]

  return (
    <main className="min-h-screen">
      {/* Hero Section */}
      <section className="relative h-[600px] flex items-center justify-center overflow-hidden bg-muted">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage:
              "url(/placeholder.svg?height=600&width=1920&query=tropical+jungle+with+reptiles+and+plants)",
          }}
        >
          <div className="absolute inset-0 bg-gradient-to-b from-background/60 via-background/40 to-background" />
        </div>

        <div className="relative z-10 container text-center space-y-6 px-4">
          <h1 className="font-serif text-5xl md:text-7xl text-balance text-foreground">
            Bienvenue dans l'univers de Natura
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto text-balance">
            Découvrez notre collection soigneusement sélectionnée de reptiles fascinants et de plantes tropicales
            exotiques
          </p>
          <div className="flex gap-4 justify-center flex-wrap">
            <Button size="lg" asChild className="rounded-full">
              <Link href="/reptiles">
                Explorer les Reptiles
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
            <Button size="lg" variant="outline" asChild className="rounded-full bg-transparent">
              <Link href="/plantes">Découvrir les Plantes</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-20 container">
        <div className="text-center mb-12 space-y-4">
          <h2 className="font-serif text-4xl md:text-5xl text-foreground">Nos Coups de Cœur</h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Une sélection de nos produits les plus populaires pour commencer votre collection
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {featuredProducts.map((product) => (
            <Link key={product.id} href={product.href}>
              <Card className="group overflow-hidden hover:shadow-lg transition-all duration-300 border-border/50">
                <div className="aspect-square overflow-hidden bg-muted">
                  <img
                    src={product.image || "/placeholder.svg"}
                    alt={product.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                </div>
                <CardContent className="p-6 space-y-2">
                  <p className="text-sm text-muted-foreground uppercase tracking-wide">{product.category}</p>
                  <h3 className="font-serif text-2xl text-foreground">{product.name}</h3>
                  <p className="text-xl font-medium text-primary">{product.price.toFixed(2)} €</p>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-20 bg-muted/30">
        <div className="container">
          <div className="grid md:grid-cols-2 gap-8">
            <Link href="/reptiles" className="group">
              <Card className="overflow-hidden hover:shadow-xl transition-all duration-300 h-[400px] relative">
                <div
                  className="absolute inset-0 bg-cover bg-center"
                  style={{
                    backgroundImage: "url(/placeholder.svg?height=400&width=600&query=exotic+reptiles+collection)",
                  }}
                >
                  <div className="absolute inset-0 bg-gradient-to-t from-background via-background/60 to-transparent" />
                </div>
                <CardContent className="relative h-full flex flex-col justify-end p-8">
                  <h3 className="font-serif text-4xl text-foreground mb-2">Reptiles</h3>
                  <p className="text-muted-foreground mb-4">Geckos, serpents, lézards et plus encore</p>
                  <Button
                    variant="secondary"
                    className="w-fit rounded-full group-hover:bg-primary group-hover:text-primary-foreground transition-colors"
                  >
                    Découvrir
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </CardContent>
              </Card>
            </Link>

            <Link href="/plantes" className="group">
              <Card className="overflow-hidden hover:shadow-xl transition-all duration-300 h-[400px] relative">
                <div
                  className="absolute inset-0 bg-cover bg-center"
                  style={{
                    backgroundImage:
                      "url(/placeholder.svg?height=400&width=600&query=tropical+exotic+plants+collection)",
                  }}
                >
                  <div className="absolute inset-0 bg-gradient-to-t from-background via-background/60 to-transparent" />
                </div>
                <CardContent className="relative h-full flex flex-col justify-end p-8">
                  <h3 className="font-serif text-4xl text-foreground mb-2">Plantes</h3>
                  <p className="text-muted-foreground mb-4">Plantes tropicales, succulentes et carnivores</p>
                  <Button
                    variant="secondary"
                    className="w-fit rounded-full group-hover:bg-primary group-hover:text-primary-foreground transition-colors"
                  >
                    Découvrir
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </CardContent>
              </Card>
            </Link>
          </div>
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="py-20 container">
        <Card className="bg-primary text-primary-foreground overflow-hidden">
          <CardContent className="p-12 text-center space-y-6">
            <h2 className="font-serif text-3xl md:text-4xl">Restez Informé</h2>
            <p className="text-primary-foreground/90 max-w-xl mx-auto">
              Inscrivez-vous à notre newsletter pour recevoir nos offres exclusives et conseils d'entretien
            </p>
            <div className="flex gap-2 max-w-md mx-auto">
              <input
                type="email"
                placeholder="Votre email"
                className="flex-1 px-4 py-3 rounded-full bg-primary-foreground text-foreground"
              />
              <Button size="lg" variant="secondary" className="rounded-full">
                S'inscrire
              </Button>
            </div>
          </CardContent>
        </Card>
      </section>

      {/* Footer */}
      <footer className="border-t border-border/40 py-12 bg-muted/20">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="font-serif text-2xl mb-4 text-foreground">Natura</h3>
              <p className="text-sm text-muted-foreground">
                Votre spécialiste en reptiles et plantes exotiques depuis 2020
              </p>
            </div>
            <div>
              <h4 className="font-medium mb-4 text-foreground">Navigation</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>
                  <Link href="/" className="hover:text-primary transition-colors">
                    Accueil
                  </Link>
                </li>
                <li>
                  <Link href="/reptiles" className="hover:text-primary transition-colors">
                    Reptiles
                  </Link>
                </li>
                <li>
                  <Link href="/plantes" className="hover:text-primary transition-colors">
                    Plantes
                  </Link>
                </li>
                <li>
                  <Link href="/about" className="hover:text-primary transition-colors">
                    À propos
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-medium mb-4 text-foreground">Aide</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>
                  <Link href="/contact" className="hover:text-primary transition-colors">
                    Contact
                  </Link>
                </li>
                <li>
                  <Link href="/faq" className="hover:text-primary transition-colors">
                    FAQ
                  </Link>
                </li>
                <li>
                  <Link href="/shipping" className="hover:text-primary transition-colors">
                    Livraison
                  </Link>
                </li>
                <li>
                  <Link href="/returns" className="hover:text-primary transition-colors">
                    Retours
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-medium mb-4 text-foreground">Légal</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>
                  <Link href="/privacy" className="hover:text-primary transition-colors">
                    Confidentialité
                  </Link>
                </li>
                <li>
                  <Link href="/terms" className="hover:text-primary transition-colors">
                    Conditions
                  </Link>
                </li>
              </ul>
            </div>
          </div>
          <div className="mt-12 pt-8 border-t border-border/40 text-center text-sm text-muted-foreground">
            <p>© 2025 Natura. Tous droits réservés.</p>
          </div>
        </div>
      </footer>
    </main>
  )
}
