export interface Product {
  id: string
  name: string
  category: "reptile" | "plante"
  price: number
  image: string
  description: string
  details: string[]
  inStock: boolean
}

export const reptiles: Product[] = [
  {
    id: "gecko-leopard",
    name: "Gecko Léopard",
    category: "reptile",
    price: 89.99,
    image: "/leopard-gecko-reptile.jpg",
    description:
      "Le gecko léopard est un lézard docile et facile à entretenir, parfait pour les débutants. Originaire d'Afghanistan et du Pakistan, il est connu pour ses magnifiques motifs tachetés.",
    details: [
      "Taille adulte: 20-25 cm",
      "Espérance de vie: 15-20 ans",
      "Température: 26-32°C",
      "Alimentation: Insectes",
      "Niveau de soin: Débutant",
    ],
    inStock: true,
  },
  {
    id: "python-royal",
    name: "Python Royal",
    category: "reptile",
    price: 149.99,
    image: "/ball-python-snake.jpg",
    description:
      "Le python royal est un serpent constricteur calme et docile, idéal pour les amateurs de serpents. Ses motifs variés et sa nature paisible en font un choix populaire.",
    details: [
      "Taille adulte: 90-150 cm",
      "Espérance de vie: 20-30 ans",
      "Température: 26-32°C",
      "Alimentation: Rongeurs",
      "Niveau de soin: Intermédiaire",
    ],
    inStock: true,
  },
  {
    id: "dragon-barbu",
    name: "Dragon Barbu",
    category: "reptile",
    price: 119.99,
    image: "/bearded-dragon-lizard.jpg",
    description:
      "Le dragon barbu est un lézard australien sociable et curieux. Avec sa personnalité attachante et son apparence unique, il fait un excellent compagnon reptilien.",
    details: [
      "Taille adulte: 40-60 cm",
      "Espérance de vie: 10-15 ans",
      "Température: 35-40°C",
      "Alimentation: Omnivore",
      "Niveau de soin: Débutant",
    ],
    inStock: true,
  },
  {
    id: "gecko-crete",
    name: "Gecko à Crête",
    category: "reptile",
    price: 79.99,
    image: "/crested-gecko-lizard.jpg",
    description:
      "Le gecko à crête de Nouvelle-Calédonie est un lézard arboricole nocturne avec une crête distinctive. Facile à maintenir et ne nécessitant pas de lampe chauffante.",
    details: [
      "Taille adulte: 15-20 cm",
      "Espérance de vie: 15-20 ans",
      "Température: 22-26°C",
      "Alimentation: Fruits et insectes",
      "Niveau de soin: Débutant",
    ],
    inStock: true,
  },
  {
    id: "boa-constrictor",
    name: "Boa Constrictor",
    category: "reptile",
    price: 199.99,
    image: "/boa-constrictor-snake.jpg",
    description:
      "Le boa constrictor est un serpent impressionnant mais docile. Originaire d'Amérique centrale et du Sud, il est apprécié pour sa beauté et son tempérament calme.",
    details: [
      "Taille adulte: 180-300 cm",
      "Espérance de vie: 20-30 ans",
      "Température: 27-32°C",
      "Alimentation: Rongeurs",
      "Niveau de soin: Avancé",
    ],
    inStock: false,
  },
  {
    id: "cameleon-panthere",
    name: "Caméléon Panthère",
    category: "reptile",
    price: 299.99,
    image: "/panther-chameleon-colorful.jpg",
    description:
      "Le caméléon panthère de Madagascar est célèbre pour ses couleurs éclatantes et sa capacité à changer de teinte. Un reptile spectaculaire pour les passionnés expérimentés.",
    details: [
      "Taille adulte: 40-50 cm",
      "Espérance de vie: 5-7 ans",
      "Température: 24-29°C",
      "Alimentation: Insectes",
      "Niveau de soin: Avancé",
    ],
    inStock: true,
  },
]

export const plantes: Product[] = [
  {
    id: "monstera-deliciosa",
    name: "Monstera Deliciosa",
    category: "plante",
    price: 34.99,
    image: "/monstera-deliciosa-tropical-plant.jpg",
    description:
      "La Monstera deliciosa, aussi appelée faux philodendron, est une plante tropicale emblématique avec ses grandes feuilles perforées. Parfaite pour apporter une touche jungle à votre intérieur.",
    details: [
      "Hauteur: 60-90 cm (pot inclus)",
      "Lumière: Indirecte moyenne à vive",
      "Arrosage: Modéré",
      "Humidité: 60-80%",
      "Niveau de soin: Facile",
    ],
    inStock: true,
  },
  {
    id: "ficus-lyrata",
    name: "Ficus Lyrata",
    category: "plante",
    price: 49.99,
    image: "/fiddle-leaf-fig.png",
    description:
      "Le ficus lyrata, ou figuier lyre, est apprécié pour ses grandes feuilles en forme de violon. Une plante d'intérieur majestueuse qui devient rapidement le point focal d'une pièce.",
    details: [
      "Hauteur: 80-120 cm (pot inclus)",
      "Lumière: Vive indirecte",
      "Arrosage: Modéré",
      "Humidité: 40-60%",
      "Niveau de soin: Intermédiaire",
    ],
    inStock: true,
  },
  {
    id: "dionee-attrape-mouche",
    name: "Dionée Attrape-Mouche",
    category: "plante",
    price: 19.99,
    image: "/venus-flytrap-carnivorous-plant.jpg",
    description:
      "La dionée attrape-mouche est une plante carnivore fascinante qui capture les insectes avec ses mâchoires. Un spectacle naturel captivant pour petits et grands.",
    details: [
      "Hauteur: 10-15 cm",
      "Lumière: Plein soleil",
      "Arrosage: Eau distillée uniquement",
      "Humidité: 60-80%",
      "Niveau de soin: Intermédiaire",
    ],
    inStock: true,
  },
  {
    id: "calathea-orbifolia",
    name: "Calathea Orbifolia",
    category: "plante",
    price: 39.99,
    image: "/calathea-orbifolia-striped-leaves.jpg",
    description:
      "La Calathea orbifolia se distingue par ses grandes feuilles rondes ornées de rayures argentées. Une plante tropicale élégante qui purifie l'air.",
    details: [
      "Hauteur: 40-60 cm",
      "Lumière: Indirecte faible à moyenne",
      "Arrosage: Régulier",
      "Humidité: 60-80%",
      "Niveau de soin: Intermédiaire",
    ],
    inStock: true,
  },
  {
    id: "nepenthes-alata",
    name: "Nepenthes Alata",
    category: "plante",
    price: 44.99,
    image: "/nepenthes-pitcher-plant-carnivorous.jpg",
    description:
      "Le Nepenthes alata est une plante carnivore tropicale avec des urnes suspendues qui piègent les insectes. Une merveille botanique pour les collectionneurs.",
    details: [
      "Hauteur: 30-50 cm",
      "Lumière: Vive indirecte",
      "Arrosage: Eau distillée",
      "Humidité: 70-90%",
      "Niveau de soin: Avancé",
    ],
    inStock: true,
  },
  {
    id: "alocasia-zebrina",
    name: "Alocasia Zebrina",
    category: "plante",
    price: 54.99,
    image: "/alocasia-zebrina-striped-stems.jpg",
    description:
      "L'Alocasia zebrina est remarquable avec ses tiges rayées comme un zèbre et ses grandes feuilles en forme de flèche. Une plante tropicale spectaculaire et graphique.",
    details: [
      "Hauteur: 50-80 cm",
      "Lumière: Vive indirecte",
      "Arrosage: Régulier",
      "Humidité: 60-80%",
      "Niveau de soin: Intermédiaire",
    ],
    inStock: false,
  },
]

export function getProductById(id: string): Product | undefined {
  return [...reptiles, ...plantes].find((p) => p.id === id)
}

export function getProductsByCategory(category: "reptile" | "plante"): Product[] {
  return category === "reptile" ? reptiles : plantes
}
