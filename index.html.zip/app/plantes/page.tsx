import Link from "next/link"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { plantes } from "@/lib/products"

export default function PlantesPage() {
  return (
    <main className="min-h-screen">
      {/* Hero Section */}
      <section className="relative h-[400px] flex items-center justify-center overflow-hidden bg-muted">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage:
              "url(/placeholder.svg?height=400&width=1920&query=tropical+exotic+plants+greenhouse+collection)",
          }}
        >
          <div className="absolute inset-0 bg-gradient-to-b from-background/70 via-background/50 to-background" />
        </div>

        <div className="relative z-10 container text-center space-y-4 px-4">
          <h1 className="font-serif text-5xl md:text-6xl text-balance text-foreground">Nos Plantes</h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto text-balance">
            Explorez notre collection de plantes tropicales exotiques et carnivores pour embellir votre intérieur
          </p>
        </div>
      </section>

      {/* Products Grid */}
      <section className="py-16 container">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {plantes.map((product) => (
            <Link key={product.id} href={`/plantes/${product.id}`}>
              <Card className="group overflow-hidden hover:shadow-lg transition-all duration-300 border-border/50 h-full">
                <div className="aspect-square overflow-hidden bg-muted relative">
                  <img
                    src={product.image || "/placeholder.svg"}
                    alt={product.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  {!product.inStock && (
                    <Badge variant="secondary" className="absolute top-4 right-4 bg-muted text-muted-foreground">
                      Rupture de stock
                    </Badge>
                  )}
                </div>
                <CardContent className="p-6 space-y-3">
                  <h3 className="font-serif text-2xl text-foreground">{product.name}</h3>
                  <p className="text-sm text-muted-foreground line-clamp-2">{product.description}</p>
                  <p className="text-xl font-medium text-primary">{product.price.toFixed(2)} €</p>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </section>
    </main>
  )
}
