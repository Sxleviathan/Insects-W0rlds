import type React from "react"
import type { Metadata } from "next"
import { Playfair_Display, Geist } from "next/font/google"
import { Analytics } from "@vercel/analytics/next"
import { CartProvider } from "@/lib/cart-context"
import { Header } from "@/components/header"
import "./globals.css"

const playfair = Playfair_Display({
  subsets: ["latin"],
  variable: "--font-serif",
  display: "swap",
})

const geist = Geist({
  subsets: ["latin"],
  variable: "--font-sans",
})

export const metadata: Metadata = {
  title: "Natura - Reptiles & Plantes Exotiques",
  description: "Découvrez notre collection de reptiles fascinants et de plantes tropicales",
  generator: "v0.app",
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="fr">
      <body className={`${geist.variable} ${playfair.variable} font-sans antialiased`}>
        <CartProvider>
          <Header />
          {children}
        </CartProvider>
        <Analytics />
      </body>
    </html>
  )
}
