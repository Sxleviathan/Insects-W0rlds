import Link from "next/link"
import { CheckCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"

export default function ConfirmationPage() {
  return (
    <main className="min-h-screen py-16">
      <div className="container">
        <div className="max-w-2xl mx-auto">
          <Card>
            <CardContent className="p-12 text-center space-y-6">
              <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center mx-auto">
                <CheckCircle className="h-10 w-10 text-primary" />
              </div>

              <div className="space-y-2">
                <h1 className="font-serif text-4xl text-foreground">Commande confirmée !</h1>
                <p className="text-muted-foreground">
                  Merci pour votre achat. Vous recevrez un email de confirmation avec les détails de votre commande.
                </p>
              </div>

              <div className="bg-muted/50 rounded-lg p-6 space-y-2">
                <p className="text-sm font-medium text-foreground">Numéro de commande</p>
                <p className="text-2xl font-mono text-primary">
                  #{Math.random().toString(36).substr(2, 9).toUpperCase()}
                </p>
              </div>

              <div className="space-y-4 pt-4">
                <p className="text-sm text-muted-foreground">
                  Votre commande sera expédiée dans les 2-3 jours ouvrables. Vous recevrez un email avec le numéro de
                  suivi dès l'expédition.
                </p>

                <div className="flex gap-4 justify-center flex-wrap">
                  <Button size="lg" asChild className="rounded-full">
                    <Link href="/">Retour à l'accueil</Link>
                  </Button>
                  <Button size="lg" variant="outline" asChild className="rounded-full bg-transparent">
                    <Link href="/reptiles">Continuer mes achats</Link>
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </main>
  )
}
